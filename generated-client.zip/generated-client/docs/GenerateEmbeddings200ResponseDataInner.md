# GenerateEmbeddings200ResponseDataInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**embedding** | **List[float]** |  | [optional] 
**index** | **int** |  | [optional] 

## Example

```python
from openapi_client.models.generate_embeddings200_response_data_inner import GenerateEmbeddings200ResponseDataInner

# TODO update the JSON string below
json = "{}"
# create an instance of GenerateEmbeddings200ResponseDataInner from a JSON string
generate_embeddings200_response_data_inner_instance = GenerateEmbeddings200ResponseDataInner.from_json(json)
# print the JSON string representation of the object
print(GenerateEmbeddings200ResponseDataInner.to_json())

# convert the object into a dict
generate_embeddings200_response_data_inner_dict = generate_embeddings200_response_data_inner_instance.to_dict()
# create an instance of GenerateEmbeddings200ResponseDataInner from a dict
generate_embeddings200_response_data_inner_from_dict = GenerateEmbeddings200ResponseDataInner.from_dict(generate_embeddings200_response_data_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


