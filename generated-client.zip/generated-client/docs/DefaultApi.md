# openapi_client.DefaultApi

All URIs are relative to *https://api.openai.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**generate_chat_completion**](DefaultApi.md#generate_chat_completion) | **POST** /chat/completions | Generate a chat completion using OpenAI GPT-4 model.
[**generate_embeddings**](DefaultApi.md#generate_embeddings) | **POST** /embeddings | Generate embeddings using the OpenAI API.


# **generate_chat_completion**
> GenerateChatCompletion200Response generate_chat_completion(generate_chat_completion_request)

Generate a chat completion using OpenAI GPT-4 model.

### Example


```python
import openapi_client
from openapi_client.models.generate_chat_completion200_response import GenerateChatCompletion200Response
from openapi_client.models.generate_chat_completion_request import GenerateChatCompletionRequest
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.openai.com/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.openai.com/v1"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.DefaultApi(api_client)
    generate_chat_completion_request = openapi_client.GenerateChatCompletionRequest() # GenerateChatCompletionRequest | 

    try:
        # Generate a chat completion using OpenAI GPT-4 model.
        api_response = api_instance.generate_chat_completion(generate_chat_completion_request)
        print("The response of DefaultApi->generate_chat_completion:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DefaultApi->generate_chat_completion: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **generate_chat_completion_request** | [**GenerateChatCompletionRequest**](GenerateChatCompletionRequest.md)|  | 

### Return type

[**GenerateChatCompletion200Response**](GenerateChatCompletion200Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **generate_embeddings**
> GenerateEmbeddings200Response generate_embeddings(generate_embeddings_request)

Generate embeddings using the OpenAI API.

### Example


```python
import openapi_client
from openapi_client.models.generate_embeddings200_response import GenerateEmbeddings200Response
from openapi_client.models.generate_embeddings_request import GenerateEmbeddingsRequest
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.openai.com/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.openai.com/v1"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.DefaultApi(api_client)
    generate_embeddings_request = openapi_client.GenerateEmbeddingsRequest() # GenerateEmbeddingsRequest | 

    try:
        # Generate embeddings using the OpenAI API.
        api_response = api_instance.generate_embeddings(generate_embeddings_request)
        print("The response of DefaultApi->generate_embeddings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DefaultApi->generate_embeddings: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **generate_embeddings_request** | [**GenerateEmbeddingsRequest**](GenerateEmbeddingsRequest.md)|  | 

### Return type

[**GenerateEmbeddings200Response**](GenerateEmbeddings200Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

