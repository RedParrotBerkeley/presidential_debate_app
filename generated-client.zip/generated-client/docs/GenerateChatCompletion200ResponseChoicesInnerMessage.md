# GenerateChatCompletion200ResponseChoicesInnerMessage


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **str** |  | [optional] 
**content** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.generate_chat_completion200_response_choices_inner_message import GenerateChatCompletion200ResponseChoicesInnerMessage

# TODO update the JSON string below
json = "{}"
# create an instance of GenerateChatCompletion200ResponseChoicesInnerMessage from a JSON string
generate_chat_completion200_response_choices_inner_message_instance = GenerateChatCompletion200ResponseChoicesInnerMessage.from_json(json)
# print the JSON string representation of the object
print(GenerateChatCompletion200ResponseChoicesInnerMessage.to_json())

# convert the object into a dict
generate_chat_completion200_response_choices_inner_message_dict = generate_chat_completion200_response_choices_inner_message_instance.to_dict()
# create an instance of GenerateChatCompletion200ResponseChoicesInnerMessage from a dict
generate_chat_completion200_response_choices_inner_message_from_dict = GenerateChatCompletion200ResponseChoicesInnerMessage.from_dict(generate_chat_completion200_response_choices_inner_message_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


