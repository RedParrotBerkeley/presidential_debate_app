# GenerateEmbeddingsRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**input** | **List[str]** |  | [optional] 
**model** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.generate_embeddings_request import GenerateEmbeddingsRequest

# TODO update the JSON string below
json = "{}"
# create an instance of GenerateEmbeddingsRequest from a JSON string
generate_embeddings_request_instance = GenerateEmbeddingsRequest.from_json(json)
# print the JSON string representation of the object
print(GenerateEmbeddingsRequest.to_json())

# convert the object into a dict
generate_embeddings_request_dict = generate_embeddings_request_instance.to_dict()
# create an instance of GenerateEmbeddingsRequest from a dict
generate_embeddings_request_from_dict = GenerateEmbeddingsRequest.from_dict(generate_embeddings_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


